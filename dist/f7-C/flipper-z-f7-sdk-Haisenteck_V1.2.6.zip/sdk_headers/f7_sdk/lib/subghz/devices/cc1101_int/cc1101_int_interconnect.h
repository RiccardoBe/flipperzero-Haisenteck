#pragma once
#include "../types.h"

#define SUBGHZ_DEVICE_CC1101_INT_NAME "cc1101_int"

typedef struct SubGhzDeviceCC1101Int SubGhzDeviceCC1101Int;

extern const SubGhzDevice subghz_device_cc1101_int;
